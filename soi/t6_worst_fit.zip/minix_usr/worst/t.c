#include <stdio.h>
#include <unistd.h>
#include <lib.h>

pid_t pid;


int hole_map( void *buffer, size_t nbytes)
{	
    int number_of_holes;
    message msg;
    msg.m1_p1 = buffer;
    msg.m1_i1 = nbytes;
    msg.m1_i2 = pid;
    
    number_of_holes = _syscall(MM, HOLE_MAP, &msg);
    
    return number_of_holes;
}
                                                                                
int
main( void )
{
        unsigned int    b[1024];
        unsigned int    *p, a, l;
        int     res;
        pid = getpid();

		res = hole_map( b, sizeof( b ) );
        printf( "[%d]\t", res );
        p = b;
        while( *p )
        {
                l = *p++;
                a = *p++; /* tu niewykorzystywane */
                printf( "%d\t", l );
        }
        printf( "\n" );
        return 0;
}
